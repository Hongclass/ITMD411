/*
   FILE:   TestArrayClass.java
   AUTHOR: Your Name Here
   DATE:   MM/DD/YYYY
   DESCR:
   In-class exercise to demonstrate the use of Array class static methods to:
     1. sort array of doubles and chars
     2. binarySearch for element in array
     3. test equality of  array contents
     4. fill array elements
*/
public class TestArrayClass {
  public static void main(String[] args) {

    // test arrays
    double[] numbers = {6.0, 4.4, 1.9, 2.9, 3.4, 3.5};
    char[] chars = {'a', 'A', '4', 'F', 'D', 'P'};
    int[] list1 = {2, 4, 7, 10};
    int[] list2 = {2, 4, 7, 10};
    int[] list3 = {4, 2, 7, 10};
	// used to pause display
	java.util.Scanner keyIn = new java.util.Scanner(System.in);


    // using java.util.Arrays.sort
    System.out.println("Before Sorting Arrays...");
    printArray(numbers);
    printArray(chars);
    // sorting arrays
    java.util.Arrays.sort(numbers);
    java.util.Arrays.sort(chars);
    System.out.println("After java.util.Arrays.sort ...");
    printArray(numbers);
    printArray(chars);
	
	// pause display
	System.out.print("Press the enter key to continue");
	keyIn.nextLine();

    // using java.util.Arrays.binarySearch
    System.out.println("Testing java.util.Arrays.binarySearch ...");
    System.out.println("Character 'F' found at index: " +
      java.util.Arrays.binarySearch(chars, 'F'));
    System.out.println("Character 'M' found at index: " +
      java.util.Arrays.binarySearch(chars, 'M'));

	// pause display
	System.out.print("Press the enter key to continue");
	keyIn.nextLine();

    // using java.util.Arrays.equals
    System.out.println("Testing java.util.Arrays.equals ...");
    System.out.print("list1 = ");
    printArray(list1);
    System.out.print("list2 = ");
    printArray(list2);
    System.out.print("list3 = ");
    printArray(list3);
    System.out.println("list1 == list2? " + java.util.Arrays.equals(list1, list2));
    System.out.println("list2 == list3? " + java.util.Arrays.equals(list2, list3));

	// pause display
	System.out.print("Press the enter key to continue");
	keyIn.nextLine();

    // using java.util.Arrays.fill
    System.out.println("Testing java.util.Arrays.fill ...");
    java.util.Arrays.fill(list1, 5);
    java.util.Arrays.fill(list2, 1, 3, 8);
    System.out.print("\n\tfilled with 5s\nlist1 = ");
    printArray(list1);
    System.out.print("\n\tfilled with 8s between elements 1 and 3\nlist2 = ");
    printArray(list2);
  }

  // overloaded methods for output of array elements
  public static void printArray(int[] array) {
    for (int i = 0; i < array.length; i++) {
      System.out.print(array[i] + " ");
    }
    System.out.print("\n");
  }

  public static void printArray(double[] array) {
    for (int i = 0; i < array.length; i++) {
      System.out.print(array[i] + " ");
    }
    System.out.print("\n");
  }

  public static void printArray(char[] array) {
    for (int i = 0; i < array.length; i++) {
      System.out.print(array[i] + " ");
    }
    System.out.print("\n");
  }

}