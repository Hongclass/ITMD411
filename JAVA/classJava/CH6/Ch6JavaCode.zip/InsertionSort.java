/*  
   Name:   Your Name
   File:   InsertionSort.java
   Date:   MM/DD/YYYY
   Class:  CIS2571-001
   Descr:
   This program demonstrates the use
   of the Insertion Sort algorithm on
   an array of doubles.
*/

public class InsertionSort {

  public static void main(String[] args) {
    // create test array
    double[] list = {1, 9, 4.5, 6.6, 5.7, -4.5};
    System.out.println("Before sorting...");
    printArray(list);
    insertionSort(list);
    System.out.println("After sorting...");
    printArray(list);
  }

  // passing an array of doubles for output of elements
  public static void printArray(double[] dArray) {
    for (double dVal: dArray) {
      System.out.print(dVal + " ");
    }
    System.out.print("\n");
  }

  /** The method for sorting the numbers */
  public static void insertionSort(double[] list) {
    for (int i = 1; i < list.length; i++) {
      /** insert list[i] into a sorted sublist list[0..i-1] so that
           list[0..i] is sorted. */
      double currentElement = list[i];
      int k;
      for (k = i - 1; k >= 0 && list[k] > currentElement; k--) {
        list[k + 1] = list[k];
      }

      // Insert the current element into list[k+1]
      list[k + 1] = currentElement;
    }
  }
}
